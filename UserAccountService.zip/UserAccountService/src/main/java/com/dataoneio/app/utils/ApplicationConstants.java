package com.dataoneio.app.utils;

/**
 * The Interface ApplicationConstants.
 */
public interface ApplicationConstants {

  /** The Constant HOME_URL. */
  public static final String HOME_URL = "/";

  /** The Constant SERVICE_UP_MESSAGE. */
  public static final String SERVICE_UP_MESSAGE = "User Account service  is Up on 9080";

  /** The Constant USER_ACCOUNT_URL. */
  public static final String USER_ACCOUNT_URL = "/api/account/";

  /** The Constant USER_NOT_FOUND. */
  public static final String USER_NOT_FOUND = "User is not exist in our database";

  /** The Constant USER_DELETE_MSG. */
  public static final String USER_DELETE_MSG = "User is deleted Successfully";

}
