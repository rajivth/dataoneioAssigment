package com.dataoneio.app.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The Class UserAccount.
 */
@Entity
public class UserAccount {

  /** The name. */
  @Column(name = "first_name", length = 50)
  private String firstName;

  /** The l name. */
  @Column(name = "last_name", length = 50)
  private String lastName;

  /** The email address. */
  @Id
  @GeneratedValue
  @Column(name = "email", length = 50, unique = true)
  private String emailAddress;

  /** The joining. */
  @Column(name = "joing_date")
  @Temporal(TemporalType.TIMESTAMP)
  private Date joining;

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public Date getJoining() {
    return joining;
  }

  public void setJoining(Date joining) {
    this.joining = joining;
  }

  @Override
  public String toString() {
    return "UserAccount [firstName=" + firstName + ", lastName=" + lastName + ", emailAddress="
        + emailAddress + ", joining=" + joining + "]";
  }

}
