package com.dataoneio.app.repository;

import com.dataoneio.app.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * The Interface UserAccountRepository.
 */
@Repository
public interface UserAccountRepository extends JpaRepository<UserAccount, String> {

}
