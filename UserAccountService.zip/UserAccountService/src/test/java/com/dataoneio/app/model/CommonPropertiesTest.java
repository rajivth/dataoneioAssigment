package com.dataoneio.app.model;

import org.agileware.test.PropertiesTester;
import org.junit.Test;

/**
 * The Class CommonProperties.
 */
public class CommonPropertiesTest {

  /**
   * Test properties.
   * 
   * @throws Exception
   *           the exception
   */
  @Test
  public void testProperties() throws Exception {
    PropertiesTester tester = new PropertiesTester();
    tester.testAll(UserAccount.class);
  }
}
